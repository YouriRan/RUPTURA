#pragma once

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <sstream>
#include <string>

#include "component.h"
#include "inputreader.h"
#include "mixture_prediction.h"

#ifdef PYBUILD
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
namespace py = pybind11;
#endif  // PYBUILD

struct BreakthroughState
{
  BreakthroughState(size_t Ngrid, size_t Ncomp, size_t maxIsothermTerms, double temperature,
                    double totalExternalPressure, double pressureGradient, double voidFraction, double particleDensity,
                    double columnEntranceVelocity, double columnLength, bool pulse, double pulseTime,
                    size_t carrierGasComponent)
      : Ngrid(Ngrid),
        Ncomp(Ncomp),
        maxIsothermTerms(maxIsothermTerms),
        temperature(temperature),
        totalExternalPressure(totalExternalPressure),
        pressureGradient(pressureGradient),
        voidFraction(voidFraction),
        particleDensity(particleDensity),
        columnEntranceVelocity(columnEntranceVelocity),
        columnLength(columnLength),
        pulse(pulse),
        pulseTime(pulseTime),
        carrierGasComponent(carrierGasComponent),
        resolution(columnLength / static_cast<double>(Ngrid)),
        timeNormalizationFactor(columnEntranceVelocity / columnLength),
        exitPressure(totalExternalPressure + pressureGradient * columnLength),
        prefactorMassTransfer(Ncomp),
        idealGasMolFractions(Ncomp),
        adsorbedMolFractions(Ncomp),
        numberOfMolecules(Ncomp),
        interstitialGasVelocity(Ngrid + 1),
        newInterstitialGasVelocity(Ngrid + 1),
        totalPressure(Ngrid + 1),
        partialPressure((Ngrid + 1) * Ncomp),
        newPartialPressure((Ngrid + 1) * Ncomp),
        adsorption((Ngrid + 1) * Ncomp),
        newAdsorption((Ngrid + 1) * Ncomp),
        equilibriumAdsorption((Ngrid + 1) * Ncomp),
        newEquilibriumAdsorption((Ngrid + 1) * Ncomp),
        pressureDot((Ngrid + 1) * Ncomp),
        newPressureDot((Ngrid + 1) * Ncomp),
        adsorptionDot((Ngrid + 1) * Ncomp),
        newAdsorptionDot((Ngrid + 1) * Ncomp),
        cachedPressure((Ngrid + 1) * Ncomp * maxIsothermTerms),
        cachedGrandPotential((Ngrid + 1) * maxIsothermTerms) {};

  size_t Ngrid;
  size_t Ncomp;
  size_t maxIsothermTerms;
  size_t numCalls;

  double temperature;
  double totalExternalPressure;
  double pressureGradient;
  double voidFraction;
  double particleDensity;
  double columnEntranceVelocity;
  double columnLength;
  bool pulse;
  double pulseTime;
  size_t carrierGasComponent;

  // derived quantities
  double resolution;
  double timeNormalizationFactor;
  double exitPressure;

  std::pair<size_t, size_t> iastPerformance{
      0,
      0,
  };

  // vector of size 'Ncomp'
  // std::vector<double> prefactor;  ///< Precomputed factors for mass transfer.
  // std::vector<double> Yi;         ///< Ideal gas mole fractions for each component.
  // std::vector<double> Xi;         ///< Adsorbed mole fractions for each component.
  // std::vector<double> Ni;         ///< Number of molecules for each component.
  std::vector<double> prefactorMassTransfer;  ///< Precomputed factors for mass transfer.
  std::vector<double> idealGasMolFractions;   ///< Ideal gas mole fractions for each component.
  std::vector<double> adsorbedMolFractions;   ///< Adsorbed mole fractions for each component.
  std::vector<double> numberOfMolecules;      ///< Number of molecules for each component.

  // vector of size '(Ngrid + 1)'
  // std::vector<double> V;     ///< Interstitial gas velocity along the column.
  // std::vector<double> Vnew;  ///< Updated interstitial gas velocities.
  // std::vector<double> Pt;    ///< Total pressure along the column.
  std::vector<double> interstitialGasVelocity;     ///< Interstitial gas velocity along the column.
  std::vector<double> newInterstitialGasVelocity;  ///< Updated interstitial gas velocities.
  std::vector<double> totalPressure;               ///< Total pressure along the column.
  std::vector<double> newTotalPressure;               ///< Total pressure along the column.
  std::vector<double> totalPressureDot;
  std::vector<double> newTotalPressureDot;
  std::vector<double> temperature;
  std::vector<double> newTemperature;
  std::vector<double> temperatureDot;
  std::vector<double> newTemperatureDot;
  std::vector<double> wallTemperature;
  std::vector<double> newWallTemperature;
  std::vector<double> wallTemperatureDot;
  std::vector<double> newWallTemperatureDot;

  // vector of size '(Ngrid + 1) * Ncomp', for each grid point, data per component (contiguous)
  // std::vector<double> P;          ///< Partial pressure at every grid point for each component.
  // std::vector<double> Pnew;       ///< Updated partial pressures.
  // std::vector<double> Q;          ///< Volume-averaged adsorption amount at every grid point for each component.
  // std::vector<double> Qnew;       ///< Updated adsorption amounts.
  // std::vector<double> Qeq;        ///< Equilibrium adsorption amount at every grid point for each component.
  // std::vector<double> Qeqnew;     ///< Updated equilibrium adsorption amounts.
  // std::vector<double> Dpdt;       ///< Derivative of P with respect to time.
  // std::vector<double> Dpdtnew;    ///< Updated derivative of P with respect to time.
  // std::vector<double> Dqdt;       ///< Derivative of Q with respect to time.
  // std::vector<double> Dqdtnew;    ///< Updated derivative of Q with respect to time.
  // std::vector<double> cachedP0;   ///< Cached hypothetical pressure.
  // std::vector<double> cachedPsi;  ///< Cached reduced grand potential over the column.
  std::vector<double> partialPressure;     ///< Partial pressure at every grid point for each component.
  std::vector<double> newPartialPressure;  ///< Updated partial pressures.
  std::vector<double> adsorption;     ///< Volume-averaged adsorption amount at every grid point for each component.
  std::vector<double> newAdsorption;  ///< Updated adsorption amounts.
  std::vector<double> equilibriumAdsorption;  ///< Equilibrium adsorption amount at every grid point for each component.
  std::vector<double> newEquilibriumAdsorption;  ///< Updated equilibrium adsorption amounts.
  std::vector<double> pressureDot;               ///< Derivative of P with respect to time.
  std::vector<double> newPressureDot;            ///< Updated derivative of P with respect to time.
  std::vector<double> adsorptionDot;             ///< Derivative of Q with respect to time.
  std::vector<double> newAdsorptionDot;          ///< Updated derivative of Q with respect to time.
  std::vector<double> moleFraction;
  std::vector<double> newMoleFraction;
  std::vector<double> moleFractionDot;
  std::vector<double> newMoleFractionDot;

  // vector of size '(Ngrid + 1) * Ngrid * maxIsothermTerms' for caching pressure
  std::vector<double> cachedPressure;  ///< Cached hypothetical pressure.
  // vector of size '(Ngrid + 1) * maxIsothermTerms' for caching grand potential
  std::vector<double> cachedGrandPotential;  ///< Cached reduced grand potential over the column.

  void initialize();
  void writeOutput(std::vector<std::ofstream>& componentStreams, std::ofstream& movieStream,
                   std::vector<Component>& components, double time);
};