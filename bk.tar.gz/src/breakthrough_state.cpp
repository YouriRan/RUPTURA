#include "breakthrough_state.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <limits>
#include <numeric>
#include <print>
#include <sstream>
#include <string>

#include "component.h"
#include "inputreader.h"
#include "mixture_prediction.h"

#ifdef PYBUILD
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
namespace py = pybind11;
#endif  // PYBUILD

void BreakthroughState::writeOutput(std::vector<std::ofstream>& componentStreams, std::ofstream& movieStream,
                                    std::vector<Component>& components, double time)
{
  for (size_t comp = 0; comp < Ncomp; ++comp)
  {
    // write breakthrough output to files
    // column 1: dimensionless time
    // column 2: time [minutes]
    // column 3: normalized partial pressure
    double normalizedPressure = totalPressure[Ngrid * Ncomp + comp] / (exitPressure * components[comp].Yi0);
    std::print(componentStreams[comp], "{} {} {}\n", time * timeNormalizationFactor, time / 60.0, normalizedPressure);
  }

  for (size_t grid = 0; grid < Ngrid; ++grid)
  {
    // write breakthrough output to files
    // column 1: column position
    // column 2: velocity
    // column 3: total pressure
    std::print(movieStream, "{} {} {} ", static_cast<double>(grid) * resolution, interstitialGasVelocity[grid],
               totalPressure[grid]);
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      // write breakthrough output to files
      // column 4 + 6 * comp: loading
      // column 5 + 6 * comp: equlibrium loading
      // column 6 + 6 * comp: partial pressure
      // column 7 + 6 * comp: normalized partial pressure
      // column 8 + 6 * comp: pressure time derivative
      // column 9 + 6 * comp: adsorption time derivative
      std::print(movieStream, "{} {} {} {} {} {} ", adsorption[grid * Ncomp + comp],
                 equilibriumAdsorption[grid * Ncomp + comp], partialPressure[grid * Ncomp + comp],
                 partialPressure[grid * Ncomp + comp] / (totalPressure[grid] * components[comp].Yi0),
                 pressureDot[grid * Ncomp + comp], adsorptionDot[grid * Ncomp + comp]);
    }
    std::print(movieStream, "\n");
  }
  std::print(movieStream, "\n\n");
}
