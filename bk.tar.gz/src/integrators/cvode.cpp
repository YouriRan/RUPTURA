#include "cvode.h"

#include <cmath>
#include <iostream>
#include <mdspan>
#include <vector>

// bool CVODE::propagate(BreakthroughState& state, std::vector<Component>& components, MixturePrediction& mixture, size_t step) {}
// void CVODE::initialize() 
// {
//     // initialize logger and context
//     SUNContext_Create(SUN_COMM_NULL, &sunContext);
//     SUNLogger_Create(SUN_COMM_NULL, 0, &sunLogger);
//     SUNContext_SetLogger(sunContext, sunLogger);

//     // create vector that cvode will operate on
//     u = N_VNew_Serial(static_cast<sunindextype>((2 * Ncomp + 3) * (Ngrid + 1)), sunContext);

//     cvodeMem = CVodeCreate(CV_BDF, sunContext);


    
// }

// static int f(sunrealtype t, N_Vector u, N_Vector udot, void* user_data) 
// {
 
// 	auto *state = reinterpret_cast<State*>(user_data);
// 	breakthrough->numCalls++;
// 	const std::pair<size_t, size_t> NcompAndNgrid = breakthrough->getNcompAndNgrid();
// 	const size_t Ncomp = NcompAndNgrid.first;
// 	const size_t Ngrid = NcompAndNgrid.second;

// 	const size_t vecLen_comp_grid = ( Ngrid + 1 ) * Ncomp;
//   const size_t vecLen_grid = Ngrid + 1;
	
//   // ************************** Extracting process variables for current time *********************
//   // Pointer pointing to first element of process variable container
//   sunrealtype *const udata  = N_VGetArrayPointer(u);
  
//   // Declaring pointers pointing to the starting elements of Q, P, T, and y vectors
// 	sunrealtype *const Qdata  = udata;
// 	sunrealtype *const Pdata  = udata + vecLen_comp_grid;
//   sunrealtype *const Tdata  = udata + vecLen_comp_grid + vecLen_grid;
//   sunrealtype *const ydata  = udata + vecLen_comp_grid + vecLen_grid + vecLen_grid;
//   sunrealtype *const Twdata = udata + vecLen_comp_grid + vecLen_grid + vecLen_grid + vecLen_comp_grid;

//   // Copying the data using pointer and vector size to store into corresponding variables.
//   // The variables are passed to first derivative calculation
// 	std::copy(Qdata, Qdata + vecLen_comp_grid, breakthrough->Qnew.begin() );
// 	std::copy(Pdata, Pdata + vecLen_grid, breakthrough->Pnew.begin() );
//   std::copy(Tdata, Tdata + vecLen_grid, breakthrough->Tnew.begin() );
// 	std::copy(ydata, ydata + vecLen_comp_grid, breakthrough->ynew.begin() );
//   std::copy(Twdata, Twdata + vecLen_grid, breakthrough->Twnew.begin() );

//   // Calculating the y_carrier_gas by enforcing sum_y_comp = 1.0
//   double sum_y;
//   for (size_t i = 1; i<Ngrid+1; ++i)
//   {
//     sum_y = 0.0;
//     // Looping over all components except carrier gas
//     for (size_t j = 1; j < Ncomp; ++j)
//     {
//       sum_y += std::min(std::max(breakthrough->ynew[i * Ncomp + j], 0.0), 1.0);
//     }
//     breakthrough->ynew[i * Ncomp + 0] = std::max((1.0 - sum_y), 0.0);
//   }

// 	// Calculating adsorption loading based on current composition, pressure and temperature (ynew, Pnew, Tnew --> Qeqnew)
//   auto mix_start = std::chrono::high_resolution_clock::now();
//   breakthrough->computeEquilibriumLoadings();
//   auto mix_end= std::chrono::high_resolution_clock::now();
//   breakthrough->mixture_duration = mix_end - mix_start;

//   // ************************** Calcualting first deriavtives *********************
//   // Pointer pointing to first element of process variable deriavtive container
//   sunrealtype *const dudata = N_VGetArrayPointer(udot);
//   // Declaring pointers pointing to the starting elements of dqdt, dPdt, dTdt, and dydt vectors
// 	sunrealtype *const dQdata   = dudata;
// 	sunrealtype *const dPdata   = dudata + vecLen_comp_grid;
//   sunrealtype *const dTdata   = dudata + vecLen_comp_grid + vecLen_grid;
// 	sunrealtype *const dydata   = dudata + vecLen_comp_grid + vecLen_grid + vecLen_grid;
//   sunrealtype *const dTwdata  = dudata + vecLen_comp_grid + vecLen_grid + vecLen_grid + vecLen_comp_grid;

//   auto break_start = std::chrono::high_resolution_clock::now();
// 	breakthrough->computeFirstDerivatives(breakthrough->Dqdt, 
//                                         breakthrough->DPdt,
//                                         breakthrough->DTdt,
//                                         breakthrough->Dydt,
//                                         breakthrough->DTwdt, 
// 																				breakthrough->Qeqnew,
//                                         breakthrough->Qnew,
// 																				breakthrough->Pnew,
//                                         breakthrough->Tnew,
//                                         breakthrough->ynew,
//                                         breakthrough->Twnew
//                                       );
  
//   auto break_end= std::chrono::high_resolution_clock::now();
//   breakthrough->breakthrough_duration = break_end - break_start;


// 	std::copy( breakthrough->Dqdt.begin(), breakthrough->Dqdt.end(), dQdata );
// 	std::copy( breakthrough->DPdt.begin(), breakthrough->DPdt.end(), dPdata );
//   std::copy( breakthrough->DTdt.begin(), breakthrough->DTdt.end(), dTdata );
// 	std::copy( breakthrough->Dydt.begin(), breakthrough->Dydt.end(), dydata );
//   std::copy( breakthrough->DTwdt.begin(), breakthrough->DTwdt.end(), dTwdata );

// 	return 0;   
// }