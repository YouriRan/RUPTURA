#include "compute.h"

#include <mdspan>

#include "utils.h"

void computeEquilibriumLoadings(BreakthroughState& state, MixturePrediction& mixture)
{
  size_t Ncomp = state.Ncomp;
  size_t Ngrid = state.Ngrid;

  // calculate new equilibrium loadings Qeqnew corresponding to the new timestep
  for (size_t grid = 0; grid < Ngrid + 1; ++grid)
  {
    // estimation of total pressure Pt at each grid point from partial pressures
    state.totalPressure[grid] = 0.0;
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      state.totalPressure[grid] += std::max(0.0, state.newPartialPressure[grid * Ncomp + comp]);
    }

    // compute gas-phase mol-fractions
    // force the gas-phase mol-fractions to be positive and normalized
    double sum = 0.0;
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      state.idealGasMolFractions[comp] = std::max(state.newPartialPressure[grid * Ncomp + comp], 0.0);
      sum += state.idealGasMolFractions[comp];
    }
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      state.idealGasMolFractions[comp] /= sum;
    }

    // use Yi and Pt[i] to compute the loadings in the adsorption mixture via mixture prediction
    state.iastPerformance +=
        mixture.predictMixture(state.idealGasMolFractions, state.totalPressure[grid], state.adsorbedMolFractions,
                               state.numberOfMolecules, &state.cachedPressure[grid * Ncomp * state.maxIsothermTerms],
                               &state.cachedGrandPotential[grid * state.maxIsothermTerms]);

    for (size_t comp = 0; comp < Ncomp; ++comp)

    {
      state.newEquilibriumAdsorption[grid * Ncomp + comp] = state.numberOfMolecules[comp];
    }
  }

  // check the total pressure at the outlet, it should not be negative
  if (state.totalPressure[0] + state.pressureGradient * state.columnLength < 0.0)
  {
    throw std::runtime_error("Error: pressure gradient is too large (negative outlet pressure)\n");
  }
}

void computeVelocity(BreakthroughState& state, std::vector<Component>& components)
{
  double idx2 = 1.0 / (state.resolution * state.resolution);
  size_t Ncomp = state.Ncomp;
  size_t Ngrid = state.Ngrid;

  // first grid point
  state.newInterstitialGasVelocity[0] = state.columnEntranceVelocity;

  // middle gridpoints
  for (size_t grid = 1; grid < Ngrid; ++grid)
  {
    // sum = derivative at the actual gridpoint i
    double sum = 0.0;
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      sum = sum -
            state.prefactorMassTransfer[comp] *
                (state.newEquilibriumAdsorption[grid * Ncomp + comp] - state.newAdsorption[grid * Ncomp + comp]) +
            components[comp].D *
                (state.newPartialPressure[(grid - 1) * Ncomp + comp] -
                 2.0 * state.newPartialPressure[grid * Ncomp + comp] +
                 state.newPartialPressure[(grid + 1) * Ncomp + comp]) *
                idx2;
    }

    // explicit version
    state.newInterstitialGasVelocity[grid] =
        state.newInterstitialGasVelocity[grid - 1] +
        state.resolution * (sum - state.newInterstitialGasVelocity[grid - 1] * state.pressureGradient) /
            state.totalPressure[grid];
  }

  // last grid point
  double sum = 0.0;
  for (size_t comp = 0; comp < Ncomp; ++comp)
  {
    sum = sum -
          state.prefactorMassTransfer[comp] *
              (state.newEquilibriumAdsorption[Ngrid * Ncomp + comp] - state.newAdsorption[Ngrid * Ncomp + comp]) +
          components[comp].D *
              (state.newPartialPressure[(Ngrid - 1) * Ncomp + comp] - state.newPartialPressure[Ngrid * Ncomp + comp]) *
              idx2;
  }

  // explicit version
  state.newInterstitialGasVelocity[Ngrid] =
      state.newInterstitialGasVelocity[Ngrid - 1] +
      state.resolution * (sum - state.newInterstitialGasVelocity[Ngrid - 1] * state.pressureGradient) /
          state.totalPressure[Ngrid];
}

void computeFirstDerivatives(std::vector<Component>& components, std::vector<double>& adsorptionDot,
                             std::vector<double>& pressureDot, const std::vector<double>& equilibriumAdsorption,
                             const std::vector<double>& adsorption, const std::vector<double>& interstitialGasVelocity,
                             const std::vector<double>& partialPressure, std::vector<double>& prefactorMassTransfer,
                             double resolution, size_t Ncomp, size_t Ngrid)
{
  double idx = 1.0 / resolution;
  double idx2 = idx * idx;

  std::mdspan<const double, std::dextents<size_t, 2>> spanPartialPressure(partialPressure.data(), Ngrid + 1, Ncomp);
  std::mdspan<const double, std::dextents<size_t, 2>> spanEquilibriumAdsorption(equilibriumAdsorption.data(), Ngrid + 1,
                                                                                Ncomp);
  std::mdspan<const double, std::dextents<size_t, 2>> spanAdsorption(adsorption.data(), Ngrid + 1, Ncomp);

  // first gridpoint
  for (size_t comp = 0; comp < Ncomp; ++comp)
  {
    double diffAdsorption = spanEquilibriumAdsorption[0, comp] - spanAdsorption[0, comp];
    adsorptionDot[comp] = components[comp].Kl * diffAdsorption;
    pressureDot[comp] = 0.0;
  }

  // middle gridpoints
  for (size_t grid = 1; grid < Ngrid; ++grid)
  {
    for (size_t comp = 0; comp < Ncomp; ++comp)
    {
      double diffAdsorption = spanEquilibriumAdsorption[grid, comp] - spanAdsorption[grid, comp];

      adsorptionDot[grid * Ncomp + comp] = components[comp].Kl * diffAdsorption;
      pressureDot[grid * Ncomp + comp] =
          (interstitialGasVelocity[grid - 1] * spanPartialPressure[grid - 1, comp] -
           interstitialGasVelocity[grid] * spanPartialPressure[grid, comp]) *
              idx +
          components[comp].D *
              (spanPartialPressure[grid + 1, comp] - 2.0 * spanPartialPressure[grid, comp] +
               spanPartialPressure[grid - 1, comp]) *
              idx2 -
          prefactorMassTransfer[comp] * diffAdsorption;
    }
  }

  // last gridpoint
  for (size_t comp = 0; comp < Ncomp; ++comp)
  {
    double diffAdsorption = spanEquilibriumAdsorption[Ngrid, comp] - spanAdsorption[Ngrid, comp];

    adsorptionDot[Ngrid * Ncomp + comp] = components[comp].Kl * diffAdsorption;
    pressureDot[Ngrid * Ncomp + comp] =
        (interstitialGasVelocity[Ngrid - 1] * spanPartialPressure[Ngrid - 1, comp] -
         interstitialGasVelocity[Ngrid] * spanPartialPressure[Ngrid, comp]) *
            idx +
        components[comp].D * (spanPartialPressure[Ngrid - 1, comp] - spanPartialPressure[Ngrid, comp]) * idx2 -
        prefactorMassTransfer[comp] * diffAdsorption;
  }
}