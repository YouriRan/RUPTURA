#pragma once

#include "breakthrough_state.h"
#include "compute.h"


#include <cvode/cvode.h> /* main integrator header file                 */
#include <nvector/nvector_serial.h> /* serial N_Vector types, fct. and macros      */
#include <sundials/sundials_dense.h> /* use generic DENSE solver in preconditioning */
#include <sundials/sundials_logger.h>
#include <sundials/sundials_types.h> /* definition of sunrealtype                      */
#include <sunlinsol/sunlinsol_spbcgs.h> /* access to SPBCGS SUNLinearSolver            */
#include <sunlinsol/sunlinsol_spfgmr.h> /* access to SPFGMR SUNLinearSolver            */
#include <sunlinsol/sunlinsol_spgmr.h> /* access to SPGMR SUNLinearSolver             */
#include <sunlinsol/sunlinsol_sptfqmr.h> /* access to SPTFQMR SUNLinearSolver           */
#include <sunnonlinsol/sunnonlinsol_newton.h> /* access to Newton SUNNonlinearSolver         */
#include <sunmatrix/sunmatrix_dense.h>
#include <sunlinsol/sunlinsol_dense.h>

struct CVODE
{
  CVODE(double timeStep, bool autoSteps, size_t numberOfSteps)
      : timeStep(timeStep), autoSteps(autoSteps), numberOfSteps(numberOfSteps) {};

  double timeStep;
  bool autoSteps;
  size_t numberOfSteps;

  SUNContext sunContext;
  SUNLogger sunLogger;
  N_Vector u;
  SUNMatrix A;
  void *cvodeMem;
  SUNNonLinearSolver solver;
  SUNLinearSolver linSolver;

  bool propagate(BreakthroughState& state, std::vector<Component>& components, MixturePrediction& mixture, size_t step);
  void initialize();

  N_Vector packState(BreakthroughState& state);
  void unpackState(N_Vector& stateVec, BreakthroughState& state);

};

static int sundialFunction(sunrealtype t, N_Vector u, N_Vector udot, void* user_data);